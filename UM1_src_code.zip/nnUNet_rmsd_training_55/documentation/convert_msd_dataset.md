Use `nnUNetv2_convert_MSD_dataset`.

Read `nnUNetv2_convert_MSD_dataset -h` for usage instructions.