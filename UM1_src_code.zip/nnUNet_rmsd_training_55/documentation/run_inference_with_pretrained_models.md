# How to run inference with pretrained models
**Important:** Pretrained weights from nnU-Net v1 are NOT compatible with V2. You will need to retrain with the new 
version. But honestly, you already have a fully trained model with which you can run inference (in v1), so 
just continue using that!

Not yet available for V2 :-(
If you wish to run inference with pretrained models, check out the old nnU-Net for now. We are working on this full steam!
